export class ParentTask{
    parentId : number;
    prntTask : String;

    constructor(){
        this.parentId=0;
        this.prntTask='';
    }
    

}